---
name: roblox-culture-currents
description: >
  Robloxゲームの新規企画・アイデア検証を行うときは必ずこのスキルを使うこと。
  GDC 2026講演（Alec Kieft / Piercen Harbut）の「Cultural Currents（文化的潮流）」
  フレームワークに基づく、Observe（観察）→ Interpret（解釈）→ Ideate（発想）の
  3段階プロセス。シグナル/ノイズ判定、Visceral Core（本能的コア）抽出、系譜マッピング、
  記号借用設計、長期定着4要素、侵略的外来種チェックを含む。
  「Roblox企画」「ゲームアイデア検証」「潮流分析」「ヒット狙い」「新作コンセプト」
  などの依頼で必ず起動。6つの専門サブエージェント
  （trend-observer / genealogy-analyst / signal-classifier /
  visceral-core-extractor / concept-ideator / idea-validator）を統括する。
---

# Roblox Culture Currents — 潮流ベース企画・検証フレームワーク

## 出典と思想

GDC Festival of Gaming 2026 講演「Catching Culture Currents」より。
登壇: Alec Kieft（99 Nights in the Forest, Break In）/ Piercen Harbut（Onett, Bee Swarm Simulator）。

**根本思想: データだけを追うな、潮流に乗れ。**
KPI・A/Bテスト偏重ではなく、プラットフォーム全体を「1つの芸術作品」として捉える
ホリスティックな姿勢。分析的アプローチでは文化の潮流が持つ力のごく一部しか捉えられない。
99 Nights は初期アナリティクスが悪くても文化への同調が「ヒットする」という正しい判断を導いた。

## 核概念定義（全エージェント共通語彙）

### Cultural Currents（文化的潮流）= 2層構造
1. **プレイヤーの大群（Roaming Hordes）**: タイクーン / シミュレータ / Brain Rot 等の
   ジャンル・メカニクスに慣れたプレイヤー集団が、ゲームからゲームへ渡り歩く集団移動のうねり。
   企画の第一問は常に「大群はどこから来るか？」
2. **メタナラティブ（ゲームの系譜）**: Roblox初期の物理サンドボックスから続く
   ジャンル・メカニクス進化の歴史。個々のゲームは孤立せず、系譜の一部として位置づける。

### Robloxの土壌3特性
- **Accessibility**: F2P・全端末・プレイヤー→開発者移行が容易
- **Streaming**: DL不要・ゲーム間シームレス移動 → 大群の高速移動を可能にする
- **Simplicity**: バグ許容・コンソール級完成度不要・高速イテレーション文化

### Visceral Core（本能的コア）
成功するゲームの根底にある、純粋で本能的な手触り。
例:「ブロックに追いかけられるスリル」「流れに身を任せる快感」「押しつぶされる衝撃」。
Canoe Without a Paddle → Build a Boat for Treasure と進化しても、コアは一貫している。
**コアは1文で言い切れる純度まで還元すること。還元できなければコア不在。**

### シグナル vs ノイズ
- **シグナル**: メカニクスと結合し、プレイヤーの行動様式そのものを変える真の潮流。
  例: Brain Rot（タイクーン的ボタン踏み・マルチプライヤーの「記号」として定着。
  名前だけでメカニクスが直感理解できる = タイクーンと同じ構造）
- **ノイズ**: 話題になるがメカニクスに影響しない一時的文化現象。
  例: Skibidi Toilet（既存ジャンルへのスキン被せのみ。行動様式を変えなかった）
- **判定基準はただ1つ: メカニクスとの結合度。**

### 記号借用（Symbol Borrowing）
既存潮流の「記号」を採用し、初見プレイヤーの学習コストをゼロ化する設計。
- 99 Nights: Dead Rails の「Sack」インベントリ採用 → どんなゲームか直感伝達
- Bee Swarm: Snow Shoveling Simulator 風の初期装備スポーン → 何をすべきか即理解

### 侵略的外来種（Invasive Species）
Robloxの文脈を理解せず、重厚なRPG・SF等の外部コンテンツを直輸入すること。
外部アイデア自体は悪くない。**順序が全て: まず潮流に乗る → その上に外部感性を融合。**

### 主導権（Authorship）とビッグスイング
大群を自ゲームに引き込むと、その潮流の主導権が開発者に与えられる。
主導権獲得後こそ本当の勝負: 自分自身のアイデンティティ・直感を注ぎ込む
「大きな決断」で、一時的流行を長続きする潮流へ昇華させる。
例: Adopt Me（家族RPで1位獲得 → ペット収集経済圏へ大胆ピボット）。

### 長期定着4要素
1. Satisfying loops（満足感のあるループ）
2. Present long-term goals（長期目標の提示）
3. Community building（コミュニティ構築）
4. Extrapolate satisfaction into key pillars（満足感を柱へと展開）

### 潮流の合流点（Confluence）
記録的ヒットは複数潮流の合流点に生まれる。
例: Grow a Garden = レトロ美学回帰 × シミュ/タイクーン系譜 × RNGムーブメント × 開発者との距離の近さ。

## 2つの動作モード

### モードA: 企画モード（ゼロから発想）
```
trend-observer ──┐
                 ├→ signal-classifier → concept-ideator → idea-validator → 提示
genealogy-analyst┘
```
1. `trend-observer`: 現在潮流スナップショット取得（Web調査必須）
2. `genealogy-analyst`: 有望ジャンルの系譜ツリー構築・空白地帯特定
3. `signal-classifier`: 候補潮流のシグナル/ノイズ判定・賞味期限予測
4. `concept-ideator`: 合流点探索 → 企画案3件生成
5. `idea-validator`: ルーブリック審査 → GO/NO-GO/条件付きGO

### モードB: 検証モード（持ち込みアイデア審査）
```
visceral-core-extractor ──┐
genealogy-analyst ────────┼→ idea-validator → 判定・改善指示
signal-classifier ────────┘        │
                                   └ NO-GO時: concept-ideator へ差し戻し（改修案生成）
```
1. `visceral-core-extractor`: アイデアから本能的コア抽出。抽出不能なら即NO-GO候補
2. `genealogy-analyst`: アイデアが乗る系譜の特定・先行作マッピング
3. `signal-classifier`: 依拠する潮流の鮮度・シグナル性確認
4. `idea-validator`: 6項目ルーブリック採点 → 判定
5. NO-GO / 条件付きGO の場合: `concept-ideator` が潮流適合形へ改修案を生成

## オーケストレーション規則

- 各エージェントの出力は次段の入力。**中間成果物は `currents-analysis/` 配下にMD保存**
  （`01-trends.md` / `02-genealogy.md` / `03-signals.md` / `04-core.md` /
  `05-concepts.md` / `06-verdict.md`）。
- Web調査系（trend-observer / genealogy-analyst）は**推測禁止・出典URL必須**。
  データが取れない項目は「未確認」と明記。
- 最終判定は必ず idea-validator が下す。他エージェントは判定しない。
- ユーザー（Ryu）の自己表現資産を concept-ideator へ渡すこと:
  CAD/CAAのドローン・武装カスタマイズ資産、Paint & Snipe のEditableImage技術、
  経済分析・ゲーム史への関心、Blender/UEFN横断パイプライン。
  ビッグスイングは「Ryu自身の表現」でなければならない（Harbut: 徹底的に自分自身の表現）。
- 判定合格後、必要に応じて既存のNDT討論体制へ接続し最終ストレステスト可。

## アンチパターン（全エージェント遵守）

- ❌ KPI・DAU予測だけで企画の良否を語る（データサイエンティスト化の禁止）
- ❌ 人気1位ゲームの表層クローン提案（大群は「次の面白いもの」を探している）
- ❌ 外部IP・重厚ジャンルの直輸入提案（侵略的外来種）
- ❌ ノイズ（スキン系ミーム）への乗車を潮流戦略と呼ぶこと
- ❌ コアを3文以上で説明する企画（純度不足）
- ❌ 主導権獲得前のビッグスイング（順序違反: まず潮流で大群を捕まえる）
