# Roblox Culture Currents — 潮流ベース企画・検証パッケージ

GDC 2026講演「Catching Culture Currents」（Alec Kieft / Piercen Harbut）の
フレームワークをClaude Code用 Skill + Sub Agent 構成に実装したもの。

## 構成

```
skills/roblox-culture-currents/SKILL.md   # 正本知識・オーケストレーション規則
agents/
├── trend-observer.md            # 観察: 現在潮流スナップショット（Web調査）
├── genealogy-analyst.md         # 系譜: メタナラティブ構築・空白地帯特定（Web調査）
├── signal-classifier.md         # 判別: シグナル/ノイズ判定・賞味期限予測
├── visceral-core-extractor.md   # 抽出: 本能的コア1文還元
├── concept-ideator.md           # 発想: 合流点探索・企画案3件生成・差し戻し改修
└── idea-validator.md            # 審査: 6項目30点ルーブリック・GO/NO-GO判定
```

## インストール

```bash
# プロジェクト単位
cp -r skills/roblox-culture-currents  <project>/.claude/skills/
cp agents/*.md                        <project>/.claude/agents/

# 全プロジェクト共通にする場合
cp -r skills/roblox-culture-currents  ~/.claude/skills/
cp agents/*.md                        ~/.claude/agents/
```

## 使い方

### 企画モード（ゼロから）
```
Robloxで新作を企画したい。潮流分析から企画案まで通しで実行して
```
→ trend-observer + genealogy-analyst → signal-classifier
→ concept-ideator（3案）→ idea-validator（判定）

### 検証モード（持ち込みアイデア）
```
このアイデアを検証して: [アイデア記述]
```
→ visceral-core-extractor + genealogy-analyst + signal-classifier
→ idea-validator（判定）→ NO-GO時は concept-ideator が改修案生成

## 中間成果物

`currents-analysis/` に段階別MD保存:
`01-trends.md` → `02-genealogy.md` → `03-signals.md` → `04-core.md`
→ `05-concepts.md` → `06-verdict.md`

## 判定基準サマリ

- GO: 24/30以上・全項目3点以上
- 条件付きGO: 18〜23点（改善指示付き）
- NO-GO: 17点以下 or コア0点 → 自動差し戻し
- 合格案は既存NDT討論体制で最終ストレステスト推奨

## 注意

- trend-observer / genealogy-analyst は出典URL必須・推測禁止
- Web調査ツール（WebSearch/WebFetch）が使える環境で実行すること
- concept-ideator はRyuの自己表現資産（CAD/CAA・Paint & Snipe・経済知見・
  Blenderパイプライン）の注入を前提。他開発者が使う場合は該当節を書き換え
