# Game Biz Suite — ゲームビジネス面 Sub-Agent + Skill 一式

Roblox主軸（CAD / CAA / Paint & Snipe）+ UEFN / VRChat・Steam副軸のビジネス運用スイート。

## 導入

プロジェクトルートに `.claude/` をマージ:

```
.claude/
├── agents/    # 6 sub-agents（既存dev系agentと共存可）
└── skills/    # 5 skills
```

Claude Codeがプロジェクトの `.claude/agents/` `.claude/skills/` を自動認識。ユーザーレベルで使う場合は `~/.claude/` 配下へ。

## 構成

- **biz-director**: 統括。週次サイクル起動・タスク分配・アクションリスト統合
- **market-research**: 競合・市場調査（月次定点）
- **aso-optimizer**: サムネ/アイコン/タイトル最適化 + A/Bテスト
- **analytics-analyst**: KPIレポート・異常検知・dev引き継ぎ
- **monetization-designer**: 価格・経済・課金設計
- **content-marketer**: SNS動画計画 + Remotion/Runwayジョブ生成
- **community-manager**: 告知文・パッチノート・フィードバック要約・EN/JPローカライズ

Skills: roblox-biz-playbook（マスター）/ roblox-aso / game-analytics / monetization-design / sns-content-pipeline

## 起動例

- `週次bizサイクル回して` → biz-director起動
- `CADのサムネ改善案` → aso-optimizer
- `先週のKPIレポート`（CSVを biz/data/raw/ に配置後）→ analytics-analyst
- `P&Sの武器スキン価格設計` → monetization-designer

## 承認ゲート

広告費投入・価格変更・公開投稿実行・外部連絡は全agent共通でユーザー承認必須（提案止まり）。

## 初回セットアップ推奨

1. `biz/` ディレクトリ作成（構造はplaybook参照）
2. market-research起動 → 競合セット定義（`biz/research/competitor-sets.md`）
3. Creator Hub CSVを `biz/data/raw/` に配置 → analytics-analystで初回ベースライン計測
