---
name: roblox-biz-playbook
description: >
  ゲームビジネス運用のマスタープレイブック。biz-director agentが統括時に必ず参照。
  「週次biz」「マーケ計画」「ビジネスレビュー」「KPI定義」「運用サイクル」など、
  ゲームのビジネス面の計画・統括・運用ルールが関わる場面ではこのスキルを必ず使うこと。
  KPI定義・週次サイクル・agent呼び出し順序・承認ゲート・ファイル配置規約を含む。
---

# Roblox Biz Playbook

対象: CAD / CAA / Paint & Snipe。Roblox主軸、UEFN・VRChat/Steam副軸。

## ファイル配置規約

```
biz/
├── reports/YYYY-WW/     # 週次KPI・アクションリスト
├── research/            # 市場・競合調査
├── aso/                 # サムネ・タイトル案とテスト結果
├── monetization/        # 価格・経済設計書
├── content/
│   ├── calendar-*.md    # 投稿カレンダー
│   ├── jobs/            # Remotion/Runwayジョブ定義
│   └── review-*.md      # 投稿振り返り
├── community/           # 告知文・フィードバック要約
├── handoff/             # dev系agentへの引き継ぎ
└── data/raw/            # Creator Hub CSVエクスポート置き場
```

## KPI定義（全レポート共通）

- **D1/D7/D30 retention**: 初回訪問日を基準日とするクラシック定義
- **ARPDAU**: 日次Robux売上（開発者取り分換算前）÷ DAU
- **CTR**: インプレッション→体験ページ or 直接プレイ転換
- **コア体験到達率**: プロジェクト毎に定義（CAD=初ドローン戦闘完了、CAA=初装備変更完了、P&S=初マッチ完了）
- 北極星指標: **D7 retention**。全施策はD7への影響で最終評価

## 週次サイクル

- 月: analytics-analyst → KPIレポート（3プロジェクト）
- 火: biz-director → 課題特定（最大3件）・タスク分配
- 水〜木: content-marketer → 動画ジョブ投入・投稿準備
- 金: aso-optimizer / monetization-designer（隔週交代）
- 随時: community-manager（アプデ・イベント時）
- 月1: market-research 定点観測

## agent呼び出し順序の原則

1. データなしに施策を作らない → 必ずanalytics-analystの最新レポートを前提にする
2. ASO・課金の変更案は market-research の競合文脈を参照する
3. 並列実行可: research / content。直列必須: analytics → director → 施策系

## 承認ゲート（全agent共通・上書き禁止）

以下はユーザー承認まで提案止まり:
広告費投入・価格変更・公開投稿の実行・外部への連絡送信・ゲーム設定の変更

## dev/biz接続

KPI異常の原因がコード・パフォーマンス・仕様の疑いがある場合、`biz/handoff/` 経由で既存dev系agent（spec-audit / performance / exploit-review / test-runner）へ引き継ぐ。形式: 症状KPI・発生時期・仮説・確認箇所・判定基準。

## 判断に迷ったら

- 施策の優先順位: D7影響大 > 実装コスト小 > 検証可能性高
- リソース競合時: ゲーム本体の更新 > マーケ施策（プロダクトなきマーケは無意味）
