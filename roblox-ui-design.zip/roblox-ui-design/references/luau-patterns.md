# Luau UI実装パターン集

SKILL.mdの規約を実装に落とす標準コード。コピーして使う前提。

## 1. Themeモジュール（単一情報源）

```lua
-- ReplicatedStorage/UI/Theme.lua
local Theme = {}

Theme.Colors = {
	bg          = Color3.fromRGB(12, 14, 18),
	surface     = Color3.fromRGB(24, 28, 36),
	textPrimary = Color3.fromRGB(240, 243, 248),
	textMuted   = Color3.fromRGB(150, 158, 170),
	accent      = Color3.fromRGB(0, 200, 255),   -- プロジェクト毎に差し替え
	danger      = Color3.fromRGB(255, 80, 90),
	success     = Color3.fromRGB(90, 220, 130),
	scrim       = Color3.fromRGB(0, 0, 0),       -- Transparency 0.35〜0.55で使用
}

Theme.Fonts = {
	display = Font.new("rbxasset://fonts/families/Michroma.json", Enum.FontWeight.Regular),
	body    = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Medium),
	bodyBold= Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold),
}

Theme.Spacing = { xs = 4, s = 8, m = 12, l = 16, xl = 24, xxl = 32 }
Theme.Radius  = { panel = 12, control = 8 }   -- 2段階厳守
Theme.Time    = { fast = 0.12, base = 0.2, slow = 0.35 }
Theme.ZLayer  = { hud = 1, window = 10, modal = 20, toast = 30, tooltip = 40 }

return Theme
```

利用側は `local T = require(...Theme)` のみ。色・時間の直書きはレビューで差し戻し。

## 2. Tweenプリセット

```lua
-- ReplicatedStorage/UI/Motion.lua
local TweenService = game:GetService("TweenService")
local T = require(script.Parent.Theme)

local Motion = {}

Motion.Info = {
	enter   = TweenInfo.new(T.Time.base, Enum.EasingStyle.Back,  Enum.EasingDirection.Out),
	exit    = TweenInfo.new(T.Time.fast, Enum.EasingStyle.Quad,  Enum.EasingDirection.In),
	press   = TweenInfo.new(0.08,        Enum.EasingStyle.Quad,  Enum.EasingDirection.Out),
	release = TweenInfo.new(0.15,        Enum.EasingStyle.Back,  Enum.EasingDirection.Out),
	count   = TweenInfo.new(0.4,         Enum.EasingStyle.Quad,  Enum.EasingDirection.Out),
}

function Motion.play(instance: Instance, info: TweenInfo, props: {[string]: any})
	local tw = TweenService:Create(instance, info, props)
	tw:Play()
	return tw
end

return Motion
```

## 3. ScreenGui標準セットアップ

```lua
local gui = Instance.new("ScreenGui")
gui.Name = "HUD"
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets  -- セーフエリア標準
gui.DisplayOrder = 1  -- Theme.ZLayer と対応させる
gui.Parent = playerGui
```

## 4. ボタンコンポーネント（押下フィードバック内蔵）

```lua
-- ReplicatedStorage/UI/Components/Button.lua
local T = require(script.Parent.Parent.Theme)
local Motion = require(script.Parent.Parent.Motion)
local SoundService = game:GetService("SoundService")

local Button = {}

function Button.new(props: {text: string, onClick: () -> (), style: "primary" | "ghost"?})
	local btn = Instance.new("TextButton")
	btn.AutoButtonColor = false
	btn.BackgroundColor3 = props.style == "ghost" and T.Colors.surface or T.Colors.accent
	btn.FontFace = T.Fonts.bodyBold
	btn.TextColor3 = T.Colors.textPrimary
	btn.TextScaled = true
	btn.Text = props.text
	btn.Selectable = true  -- ゲームパッド到達可能に

	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, T.Radius.control)
	corner.Parent = btn

	local sizeCon = Instance.new("UITextSizeConstraint")
	sizeCon.MinTextSize = 14
	sizeCon.MaxTextSize = 22
	sizeCon.Parent = btn

	local scale = Instance.new("UIScale")
	scale.Parent = btn

	btn.MouseButton1Down:Connect(function()
		Motion.play(scale, Motion.Info.press, { Scale = 0.92 })
	end)
	btn.MouseButton1Up:Connect(function()
		Motion.play(scale, Motion.Info.release, { Scale = 1 })
	end)
	btn.Activated:Connect(function()
		SoundService:PlayLocalSound(SoundService.UI.Click) -- SE配置は各プロジェクト規約
		props.onClick()
	end)
	return btn
end

return Button
```

要点: `AutoButtonColor=false`（テーマ外の色変化を殺す）、`Activated`（タッチ/マウス/パッド共通発火）、Size直Tweenでなく**UIScaleをTween**（レイアウト再計算回避）。

## 5. ウィンドウ開閉（CanvasGroup演出）

```lua
local function openWindow(window: CanvasGroup)
	window.GroupTransparency = 1
	local scale = window:FindFirstChildOfClass("UIScale") or Instance.new("UIScale", window)
	scale.Scale = 0.92
	window.Visible = true
	Motion.play(window, Motion.Info.enter, { GroupTransparency = 0 })
	Motion.play(scale,  Motion.Info.enter, { Scale = 1 })
end

local function closeWindow(window: CanvasGroup)
	local scale = window:FindFirstChildOfClass("UIScale")
	Motion.play(scale, Motion.Info.exit, { Scale = 0.95 })
	Motion.play(window, Motion.Info.exit, { GroupTransparency = 1 }).Completed:Once(function()
		window.Visible = false  -- 必ず非表示まで落とす
	end)
end
```

注意: CanvasGroupは内容をテクスチャ化 → 大面積・高頻度更新には常用しない。開閉演出専用にし、静止時は通常Frameでも可。

## 6. レスポンシブ雛形（パネル）

```lua
local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 0.5)
panel.Position = UDim2.fromScale(0.5, 0.5)
panel.Size = UDim2.fromScale(0.9, 0.8)          -- Scale主体

local sizeCon = Instance.new("UISizeConstraint")
sizeCon.MaxSize = Vector2.new(720, 560)          -- デスクトップで間延び防止
sizeCon.MinSize = Vector2.new(320, 400)          -- 最小スマホ保証
sizeCon.Parent = panel

local ratio = Instance.new("UIAspectRatioConstraint")
ratio.AspectRatio = 0.9                          -- 必要な画面のみ
ratio.Parent = panel
```

## 7. 通知トースト（プール運用）

```lua
-- 生成/破棄連打禁止。N個作り置き→使い回し
local POOL_SIZE = 5
local pool = {}
for i = 1, POOL_SIZE do
	pool[i] = { frame = buildToastFrame(), busy = false }
end

local function showToast(text: string)
	for _, slot in pool do
		if not slot.busy then
			slot.busy = true
			slot.frame.Label.Text = text
			openWindow(slot.frame)
			task.delay(2.5, function()
				closeWindow(slot.frame)
				task.wait(T.Time.fast)
				slot.busy = false
			end)
			return
		end
	end
	-- 全スロット使用中: 最古を上書き（キュー実装は各プロジェクト）
end
```

## 8. 数値カウントアップ

```lua
local function tweenNumber(label: TextLabel, from: number, to: number, fmt: string?)
	local nv = Instance.new("NumberValue")
	nv.Value = from
	nv:GetPropertyChangedSignal("Value"):Connect(function()
		label.Text = string.format(fmt or "%d", nv.Value)
	end)
	Motion.play(nv, Motion.Info.count, { Value = to }).Completed:Once(function()
		nv:Destroy()
	end)
end
```

## 9. ゲームパッドナビゲーション

```lua
local GuiService = game:GetService("GuiService")
local UserInputService = game:GetService("UserInputService")

-- 選択カーソルをテーマ準拠に（デフォルト青枠禁止）
local function applySelectionCursor(btn: GuiObject, cursorTemplate: GuiObject)
	btn.SelectionImageObject = cursorTemplate
end

-- ウィンドウを開いたら最初のボタンへフォーカス
local function focusWindow(window: GuiObject)
	if UserInputService.GamepadEnabled then
		GuiService.SelectedObject = window:FindFirstChild("PrimaryButton", true)
	end
end

-- 明示配線（自動推測に任せない）
btnA.NextSelectionDown = btnB
btnB.NextSelectionUp = btnA
-- 閉じる: ButtonB
UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.KeyCode == Enum.KeyCode.ButtonB and currentWindow then
		closeWindow(currentWindow)
		GuiService.SelectedObject = nil
	end
end)
```

## 10. 入力種別の動的表示切替

```lua
local UserInputService = game:GetService("UserInputService")

local function currentInputType(): "touch" | "gamepad" | "kbm"
	local last = UserInputService:GetLastInputType()
	if last == Enum.UserInputType.Touch then return "touch" end
	if last.Name:match("^Gamepad") then return "gamepad" end
	return "kbm"
end

UserInputService.LastInputTypeChanged:Connect(function()
	updateKeyPromptIcons(currentInputType())  -- 「Eで拾う」⇔「△で拾う」等
end)
```

## 11. HUD更新の間引き

```lua
-- 毎フレーム更新禁止。イベント駆動 + 高頻度値のみ間引き
local acc = 0
RunService.Heartbeat:Connect(function(dt)
	acc += dt
	if acc < 0.1 then return end  -- 10Hz上限
	acc = 0
	if hudDirty then
		refreshHud()
		hudDirty = false
	end
end)
```

## アンチパターン即差し戻しリスト

- コンポーネント内の Color3/Font/TweenInfo 直書き
- Size を Offset 固定で組んだ全画面UI
- hover前提のツールチップのみで情報提供（タッチで詰む）
- Size直接Tweenによるレイアウト毎フレーム再計算
- 通知の Instance.new/Destroy 連打
- Visible=false にせず透明化だけで「閉じた」ことにする（入力・描画が残る）
