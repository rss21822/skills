# {PROJECT_NAME} — 詳細設計書 v1.0
<!-- tech-design-writer用骨格。「本書＋データ定義書のみでLuau実装が完了できる」解像度で展開 -->

| 項目 | 内容 |
|---|---|
| 対象 | Roblox / Luau（`--!strict`） |
| スコープ | MVP：{P0範囲を転記} |
| 上位文書 | {PROJECT} GDD v1.0 |
| 実データ | 全バランス数値はデータ定義書が正本（本書はスキーマ・ロジック・構造定数のみ） |

実装者への指示：構造定数（GameConfig）は本書が正。全バランス数値は`Shared/`配下のModuleScriptにのみ記述、ロジックへのハードコード禁止。

## 0. 全体アーキテクチャ図
<!-- Client/Server/Sharedの3層ASCII図＋信頼モデル（サーバー正本の列挙、クライアント所有の範囲、AntiCheat担保） -->

## 1. ファイル構成と責務一覧
<!-- ディレクトリツリー＋各ファイル1行責務。Builders/（Instance宣言生成）を標準搭載。初期化規約：Init(deps)/Start()・依存順配列・循環参照禁止・now()注入テスタビリティ -->

## 2. Shared層仕様
### 2.1 Types.luau  <!-- export type完全版。ProjectileState.age等、寿命/経過系フィールドの漏れ注意 -->
### 2.2 GameConfig.luau  <!-- Match/Combat/Movement/AntiCheat/Arena/Lockon/Economy等。構造定数は本書が正 -->
### 2.3 StatCalculator  <!-- 計算手順を番号列挙。クランプ規則・丸め規則（切捨て桁）明記。検算例はデータ定義書参照 -->
### 2.4 {弾道等コアSolver}  <!-- 公開API（依存注入形式）＋kind別アルゴリズム＋積分法の仕様化＋消滅条件 -->

## 3. 通信仕様（Remotes）
<!-- 全RemoteEvent/Function：引数型・方向・送信条件・検証・payload構造。「クライアントはIDと数値を送らない」原則。レート制限 -->

## 4. サーバーService詳細（1）試合進行
### 4.1 MatchService  <!-- 内部状態＋状態遷移表（現状態|イベント|ガード|アクション|次状態）全行＋実装規約（世代カウンタ・同フレーム競合優先順・transition純関数分離） -->

## 5. サーバーService詳細（2）戦闘・支援
<!-- CombatService：内部状態／ライフサイクル／N段検証（分離関数）／弾シミュ／resolveHit（爆発分岐規則・減衰式・自傷）／defeated処理。
StatusEffect等の支援Service／ArenaService（スポーン規約・物理制御Constraint・NetworkOwner）／AntiCheat（照合式・除外フラグ）／LoadoutService（検証手順・拒否reason列挙）／DataService（スキーマ・UpdateAsync・Elo式）／EquipmentMounter（Weld一体化要点）
§5.9 Builders：手作業構築禁止・API・BuildSpecs・冪等・実行タイミング -->

## 6. クライアントController詳細
<!-- Movement（フレーム処理番号列挙・リスク領域の隔離モジュール＝F切替require1行）／Input（デバイス別表・px配置・操作予算上限）／Camera／Weapon（予測演出とサーバー正の同期規約）／VFX（トリガ表）／UI（画面はMatchState完全追従・Coming Soon枠） -->

## 7. エッジケース確定仕様
<!-- 表≥10件：ケース｜挙動。同フレーム相打ち・切断・タイムアップ同値・境界張り付き等 -->

## 8. 重要技術判断（設計根拠の記録）
<!-- 番号列挙：採用理由（却下案があれば併記）。AIの再発明・改悪防止 -->

## 9. 本設計の意図的な割り切り（MVP後に再訪）

## 改訂履歴
- v1.0：初版
