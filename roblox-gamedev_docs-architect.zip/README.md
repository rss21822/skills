# roblox-docs-architect 導入手順

## 配置
- `.claude/skills/roblox-docs-architect/` → プロジェクト直下 or `~/.claude/skills/`（全プロジェクト共通）
- `.claude/agents/*.md`（5体） → プロジェクト直下 or `~/.claude/agents/`

## 使い方
Claude Codeで「新規Robloxゲームのドキュメント一式を作成」等と指示→スキル起動→D0質問票（12問）に回答→承認2回（GDD後・最終）で文書8種が docs/ に生成される。

## 構成
- SKILL.md：D0〜D5ワークフロー統括
- templates/×8：各文書の骨格（§構成＋必須要素＋執筆指示）
- checklists/consistency.md：D4監査の20項目
- agents×5：gdd-writer / tech-design-writer / dev-process-writer / doc-consistency-auditor / sub-spec-writer
