# Runway 動画AI制作システム v2（音声一気通貫対応）

Runway（API＋MCP）×ElevenLabs MCP×Remotion の動画量産パイプライン。
Skill 9本 + Agent 8役 + infra。企画→脚本→ボイス→映像→QC→合成→書き出しを一気通貫。

## 全体像（v2: voice-first）

```
企画 → scriptwriter(台本/話者) → voice-director(声設計→TTS→実尺) ←ElevenLabs MCP
   → director(shotlist/尺=音声実尺基準/予算/経路指定)
   → prompt-writer(英語prompt) → media-generator(Runway API or MCP)
   → qc-reviewer(映像QC+音声QC) → compositor(concat→mux→テロップ→3比率)
   → mux後QC → archivist(DB/台帳/資産化)
```

- **voice-first原則**: セリフ有り制作は音声実尺が動画尺を決める（動画は5/10s刻み）。
  ナレ無し環境映像のみ video-first。判定は director（`av-sync-produce` 準拠）。
- **リップシンク回避**: セリフはナレーション/引き/後ろ姿/バイザー越し構図に乗せる設計。

## 実行環境

- **一気通貫の拠点 = Claude Code（Desktop）**。
  ElevenLabs MCP=ローカルstdio、mux=ffmpeg、合成=Remotion のため。
- Runway MCP=リモート（claude.ai でも可）→ 企画〜映像生成までは chat でも回る。
- Runway API（generate.py）は従来通り量産・自動化用。

## ディレクトリ

```
runway-video-system/
├── skills/
│   ├── runway-gen/               # [基盤] API生成: generate.py + cost.py
│   ├── mcp-video-gen/            # Runway MCP生成規約・API使い分け
│   ├── video-qc/                 # 映像検査ゲート: qc.py
│   ├── runway-prompt-craft/      # 日本語意図→英語prompt・資産化
│   ├── storyboard-to-video/      # 企画→shotlist JSON（音声フィールド対応）
│   ├── character-voice/          # ElevenLabs: 声設計/TTS/SE/BGM + voice_direction.md
│   ├── av-sync-produce/          # 一気通貫指揮 + avmux.py(実尺/fit/mux/concat)
│   ├── runway-remotion-pipeline/ # テロップ/HUD/3比率書出
│   └── aleph-gameplay-enhance/   # 実プレイ×Aleph補正
├── agents/                       # 8役: director(Opus) / scriptwriter / voice-director /
│   #  prompt-writer / media-generator / qc-reviewer / compositor / archivist(Haiku)
├── infra/
│   ├── cost_ledger.csv           # Runway API台帳（generate.py自動）
│   ├── media_cost_ledger.csv     # Runway MCP + ElevenLabs台帳（ledger.py）
│   ├── ledger.py                 # 3系統統合 add/report
│   ├── voice_library.json        # キャラ↔voice_id台帳（オリジナル声のみ）
│   ├── prompt_db.jsonl           # 生成DB（archivist追記）
│   ├── shotlists/                # shotlist JSON置場
│   └── reference_library/        # 参照画像（entity別 front/side/top）
└── README.md
```

## セットアップ

1. **Runway API**: `pip install runwayml requests` + env `RUNWAYML_API_SECRET`
2. **Runway MCP**: claude.ai/Desktop=設定→コネクタ→ `https://mcp.runwayml.com/mcp` /
   Code=`claude mcp add --transport http runway https://mcp.runwayml.com/mcp`
3. **ElevenLabs MCP**: `ELEVENLABS_API_KEY` 取得 → Desktop/Code 設定に
   `{"command":"uvx","args":["elevenlabs-mcp"],"env":{"ELEVENLABS_API_KEY":"..."}}`
   （Windows: Developer Mode必須。出力先は ELEVENLABS_MCP_BASE_PATH をプロジェクト配下に）
4. **共通**: ffmpeg/ffprobe、Remotion（既存流用）

## コスト3系統 ⚠️

- runway_api: API課金。generate.py が cost_ledger.csv に自動記録
- runway_mcp: consumerプランcredit。`python infra/ledger.py add --billing runway_mcp ...`
- elevenlabs: ElevenLabs credit（無料1万/月、voice design重い）。同 `--billing elevenlabs`
- 横断集計: `python infra/ledger.py report --budget <円>`

## 導入順（v2）

1. ElevenLabs MCP導入 → `check_subscription` → UGC Gameナレーター1体設計
   （`character-voice` + `voice_direction.md` テンプレ）
2. voice_library.json 登録 → 台本1本TTS → `avmux.py probe/fit` 動作確認
3. mcp-video-gen で試作1カット（Runway MCP経由）
4. **最小1本貫通**: CAD 15秒縦（ナレ1話者×3ショット×BGM）を手動フローで
5. 型が固まったら Agent Team 化（director が全体指揮）

## 制作の合言葉

- credit は現金。試作→選抜→本番。盲目再生成禁止（QC先行）。
- 音声は行単位修正。全文再TTSしない。
- 文字は Remotion、口パクは構図で回避、尺は音声から。
