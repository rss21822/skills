# prompt_db.jsonl

生成1件 = 1行の JSON Lines。archivist が追記。改変せず追記のみ。

## 1行のスキーマ

```json
{
  "ts": "2026-07-06T12:00:00",
  "project": "CAD",
  "shot": "s01",
  "model": "gen4.5",
  "gen_mode": "i2v",
  "ratio": "1280:720",
  "duration": 5,
  "seed": 12345,
  "refs": ["CAD/drone_A/front.png"],
  "prompt_en": "FPV shot, ...",
  "prompt_intent_jp": "ドローン起動",
  "src": "assets/CAD/20260706_s01_gen4.5_12345.mp4",
  "qc": "pass",
  "credits": 60
}
```

## 使い道

- 分析: どの model/prompt/seed が PASS 率高いか。
- 見積: 実績 credits から次回予算を精緻化。
- 再現: seed + prompt で良ショット再生成・微修正。
- 資産: PASS 行の prompt を templates.md へ、記事ネタへ。

## 集計例

```bash
# PASS 率
jq -s 'group_by(.model)[] | {model:.[0].model, n:length,
  pass:(map(select(.qc=="pass"))|length)}' infra/prompt_db.jsonl
# 累計 credit
jq -s 'map(.credits)|add' infra/prompt_db.jsonl
```
