#!/usr/bin/env python3
"""
3系統コスト統合台帳。
  billing = runway_api（generate.py自動、cost_ledger.csv） /
            runway_mcp（手動/agent追記） / elevenlabs（手動/agent追記）
runway_mcp と elevenlabs は media_cost_ledger.csv に本CLIで追記。
report は cost_ledger.csv(API) も合算して3系統横断で集計。

使い方:
  python ledger.py add --billing runway_mcp --item "s01 gen4.5 5s" --credits 60
  python ledger.py add --billing elevenlabs --item "s01 tts 120字" --credits 150 --jpy 25
  python ledger.py report [--budget 30000]
"""
import argparse
import csv
import datetime as dt
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
MEDIA = HERE / "media_cost_ledger.csv"
API = HERE / "cost_ledger.csv"

# 概算単価（実レートで随時更新）
USD_PER_RUNWAY_CREDIT = 0.05
JPY_PER_USD = 155.0
# ElevenLabs は credit->円 の直接換算が困難(プラン依存) -> --jpy 手動指定を推奨、
# 未指定なら jpy=0 で記録し credit のみ管理。


def add(a):
    new = not MEDIA.exists()
    jpy = a.jpy
    if jpy is None:
        jpy = round(a.credits * USD_PER_RUNWAY_CREDIT * JPY_PER_USD, 1) \
            if a.billing == "runway_mcp" else 0.0
    with MEDIA.open("a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["ts", "billing", "item", "credits", "jpy", "note"])
        w.writerow([dt.datetime.now().isoformat(timespec="seconds"),
                    a.billing, a.item, a.credits, jpy, a.note])
    print(f"[ledger] {a.billing}  {a.item}  {a.credits}cr  約{jpy}円")


def report(budget):
    month = dt.datetime.now().strftime("%Y-%m")
    agg = defaultdict(lambda: [0, 0.0])          # billing -> [credits, jpy]
    magg = defaultdict(lambda: [0, 0.0])         # 今月分
    # media ledger
    if MEDIA.exists():
        with MEDIA.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                c, j = int(float(r["credits"])), float(r["jpy"])
                agg[r["billing"]][0] += c; agg[r["billing"]][1] += j
                if r["ts"].startswith(month):
                    magg[r["billing"]][0] += c; magg[r["billing"]][1] += j
    # API ledger (cost_ledger.csv, generate.py 出力)
    if API.exists():
        with API.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                c, j = int(float(r["credits"])), float(r["jpy"])
                agg["runway_api"][0] += c; agg["runway_api"][1] += j
                if r["ts"].startswith(month):
                    magg["runway_api"][0] += c; magg["runway_api"][1] += j

    print("=== 3系統コスト集計 ===")
    total_jpy = month_jpy = 0.0
    for b in ("runway_api", "runway_mcp", "elevenlabs"):
        c, j = agg.get(b, [0, 0.0]); mc, mj = magg.get(b, [0, 0.0])
        total_jpy += j; month_jpy += mj
        note = "" if b != "elevenlabs" or j > 0 else "  (円換算はプラン依存・credit管理)"
        print(f"  {b:12s} 累計 {c:8d}cr 約{j:9,.0f}円 | 今月 {mc:6d}cr 約{mj:7,.0f}円{note}")
    print(f"  {'-'*60}")
    print(f"  円換算合計   累計 約{total_jpy:,.0f}円 | 今月({month}) 約{month_jpy:,.0f}円")
    if budget:
        pct = month_jpy / budget * 100
        print(f"\n  月次上限 {budget:,}円 に対し {pct:.0f}%  [{'#' * int(pct // 5)}]")
        if pct >= 80:
            print("  [!] 上限80%超。ペース注意。")
        if pct >= 100:
            print("  [!!] 上限超過。")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("add")
    p.add_argument("--billing", required=True,
                   choices=["runway_mcp", "elevenlabs"])
    p.add_argument("--item", required=True)
    p.add_argument("--credits", type=int, required=True)
    p.add_argument("--jpy", type=float, default=None)
    p.add_argument("--note", default="")
    p = sub.add_parser("report")
    p.add_argument("--budget", type=int, default=0)
    a = ap.parse_args()
    if a.cmd == "add":
        add(a)
    else:
        report(a.budget)


if __name__ == "__main__":
    main()
