# 参照画像ライブラリ

Runway gen4 の一貫性維持は参照画像が主。キャラ・機体・艦船・場所ごとに
正面/側面/俯瞰の3枚セットを管理。i2v / t2i の参照に使い回す。

## 構造

```
reference_library/
├── CAD/                      # Custom Armament Drones
│   ├── drone_A/
│   │   ├── front.png         # 正面
│   │   ├── side.png          # 側面
│   │   └── top.png           # 俯瞰
│   └── base_coastal/
│       ├── front.png ...
├── CAA/                      # Custom Armament Avatar
│   └── destroyer_kai/ ...
└── PaintSnipe/               # Paint & Snipe!
    └── sniper_camo/ ...
```

## 規約

- 命名: `{entity}/{view}.png`。view = front/side/top（必要なら 3q=3/4視点 追加）。
- 解像度: 長辺 1024px 以上、背景は無地 or シンプル（識別特徴を明確に）。
- 出所: Roblox/UEFN からのレンダー、Blender書き出し、または gen4_image 生成。
  ゲーム実素材由来を推奨（実物と一致 → 一貫性UP）。
- 1エンティティ最低 front。理想は front/side/top の3枚。多視点ほど i2v 一貫性が上がる。

## 使い方

```bash
# 参照フレーム生成（既存3枚を元に新カット用の第一フレーム作成）
python skills/runway-gen/scripts/generate.py t2i \
  --model gen4_image --prompt "drone_A banking, canyon bg, midday" \
  --ratio 1280:720 --project CAD --shot s01_ref \
  --out assets/CAD/
# -> その画像を i2v の --image に渡す
```

gen4 は参照 1-3 枚まで受ける。複数渡すほど identity 維持が安定。
storyboard-to-video skill がショットごとにどの参照を使うか指定する。
