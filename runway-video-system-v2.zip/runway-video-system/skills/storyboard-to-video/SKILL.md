---
name: storyboard-to-video
description: >
  記事・GDD・企画メモから動画のショットリスト(JSON)を生成するスキル。各ショットの
  尺・カメラ・使用参照画像・prompt を構造化し、gen4_image で参照フレーム先行生成 →
  image-to-video の2段構えを設計する。キャラ・場所・オブジェクトのシーン間一貫性を
  参照画像ライブラリで担保する。「動画の構成」「絵コンテ」「ショットリスト」
  「この記事を動画に」「トレーラー作りたい」と言われた時に必ず使う。生成の前段として
  runway-prompt-craft と runway-gen をつなぐ設計スキル。
---

# storyboard-to-video

企画 → ショットリスト JSON → 生成。バラバラに生成せず全体設計してから回す。

## 入力

記事 / GDD / TDD / 企画メモ / トレーラー要件。尺（例: 30s 縦動画）とプラットフォーム
（TikTok/Shorts/UGCメディア埋込）を確認。不明なら尺と縦横比だけ聞く。

## 出力: ショットリスト JSON

スキーマ詳細 `references/shotlist_schema.md`。要旨:

```json
{
  "project": "CAD",
  "title": "CAD ローンチトレーラー",
  "ratio": "720:1280",
  "total_sec": 30,
  "shots": [
    {
      "id": "s01",
      "sec": 4,
      "beat": "掴み: 機体起動",
      "shot_type": "Close up",
      "refs": ["CAD/drone_A/front.png"],
      "prompt_intent_jp": "ドローンのローターが回り始める",
      "camera": "slow push-in",
      "lighting": "hangar cold light",
      "model": "gen4.5",
      "gen_mode": "i2v"
    }
  ]
}
```

## フロー

1. 素材読解 → beat 分解（掴み/展開/クライマックス/CTA）。縦動画は掴み最初の2秒が命。
2. 各 beat をショット化。尺配分（合計 = total_sec）。
3. 各ショットに参照画像を割当（`infra/reference_library/` から）。同一エンティティは
   同じ参照を使い回す → シーン間一貫性。無ければ「要撮影/要生成」フラグ。
4. `prompt_intent_jp` を書く。英語化は `runway-prompt-craft` が担当。
5. 2段構え設計: 参照フレーム未整備のショットは gen4_image で第一フレーム先行生成 →
   その画像を i2v の参照に。整備済なら直接 i2v。
6. director agent に JSON を渡す or ユーザー確認 → generator が順次生成。

## 一貫性ルール

- 同じ機体/艦船/キャラは全ショットで同一参照画像。text 記述もブレさせない。
- 場所も参照で固定できると背景の連続性が出る。
- gen4 参照は 1-3 枚。identity 重要なショットは複数枚渡す。

## 縦動画(SNS)特有

- 掴み 0-2秒: 動き大・被写体アップ。静かな引きは離脱。
- 文字情報は Remotion テロップ（`runway-remotion-pipeline`）。AI 生成文字は使わない。
- ループ用途なら先頭↔末尾を繋げる設計（`video-qc` でループ継ぎ目確認）。

## 出力後

JSON を `infra/shotlists/{project}_{title}.json` に保存。director/generator が消費。
