# ショットリスト JSON スキーマ

## トップレベル

- `project` (str): CAD / CAA / PaintSnipe / UGCMedia 等。参照ライブラリ・保存先のキー。
- `title` (str): 動画名。
- `ratio` (str): `720:1280`(縦) / `1280:720`(横) / `1080:1080`(正方)。
- `total_sec` (int): 合計尺。shots の sec 合計と一致させる。
- `platform` (str, optional): tiktok / shorts / media_embed。テロップ・safe area に影響。
- `shots` (array): 下記ショット定義の配列。

## ショット定義

- `id` (str): s01, s02 ... 連番。ファイル名 shot に使う。
- `sec` (int): このショットの秒数。Runway は 5s/10s 単位が扱いやすい。
- `beat` (str): 物語上の役割（掴み/展開/クライマックス/CTA）。
- `shot_type` (str): Close up / Wide shot / Aerial view / FPV / Tracking shot。
- `refs` (array[str]): 使用参照画像パス（reference_library 相対）。空なら要生成/撮影。
- `prompt_intent_jp` (str): 日本語意図。英語化は prompt-craft が担当。
- `prompt_en` (str, optional): prompt-craft 出力を後で埋める。
- `camera` (str): slow push-in / arc / truck / orbit / static。
- `lighting` (str): golden hour / overcast / hangar cold / dusk 等。
- `model` (str): gen4_turbo(試作) / gen4.5(本番) / aleph(編集)。
- `gen_mode` (str): t2i / i2v / v2v。
- `needs_asset` (bool, optional): true なら参照未整備。director が撮影/生成タスク化。
- `status` (str, optional): planned / generating / qc / pass / fail。archivist が更新。
- `seed` (int, optional): 確定後に記録。再現用。

## 音声フィールド（voice-first 制作時に使用）

- `dialogue` (str): このショットに乗るセリフ/ナレーション（日本語原文）。無音ショットは省略。
- `speaker` (str): 話者キャラ識別子（voice_library.json の character と一致）。
- `voice_id` (str): 引き当てた ElevenLabs voice_id。voice-director が記入。
- `audio_file` (str): 生成音声パス `assets/{project}/vo/{shot}_{speaker}.mp3`。
- `audio_sec` (float): TTS実尺（ffprobe実測）。**このショットの sec はここから確定**
  （`avmux.py fit`: audio_sec+margin を5s刻み切り上げ）。

## バリデーション

- Σ shots[].sec == total_sec。
- 縦動画は掴みショット(先頭)を sec<=2 の動き大に寄せるのが理想。
- gen_mode=i2v は refs 必須（空なら先に t2i or 撮影）。
- model=gen4.5 は director 承認フラグが立ってから（turbo で構図確定後が原則）。
- dialogue 有り → speaker/voice_id/audio_sec 必須（voice-first: 音声確定前に本番映像生成禁止）。
- audio_sec + margin > sec は違反（音声が映像より長い）→ 台本削減 or 尺再確定。
- dialogue 有りショットの構図はリップシンク回避（引き/後ろ姿/バイザー越し/ナレーション）。

## 保存

`infra/shotlists/{project}_{title}.json`。generator が読み、生成ごとに status/seed 追記。
