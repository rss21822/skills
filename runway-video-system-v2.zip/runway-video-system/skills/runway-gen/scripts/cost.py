#!/usr/bin/env python3
"""
生成前コスト概算 & 台帳集計。generate.py と定義を共有。
使い方:
  python cost.py --model gen4.5 --duration 5 --count 4     # 概算
  python cost.py --model gen4_image --images 3             # 画像概算
  python cost.py --report                                  # 台帳集計
  python cost.py --report --budget 20000                   # 月次上限アラート(円)
"""
import argparse
import csv
import datetime as dt
import os
from collections import defaultdict
from pathlib import Path

CREDIT_PER_SEC = {"gen4_turbo": 5, "gen4.5": 12, "aleph": 15}
CREDIT_PER_IMAGE = {"gen4_image": 5, "gpt_image_2": 8}
USD_PER_CREDIT = 0.05
JPY_PER_USD = 155.0
LEDGER = Path(os.environ.get("RUNWAY_LEDGER",
              Path(__file__).resolve().parents[3] / "infra" / "cost_ledger.csv"))


def estimate(model, duration, count, images):
    if images:
        credits = CREDIT_PER_IMAGE.get(model, 5) * images
        unit = f"{images}枚"
    else:
        per = CREDIT_PER_SEC.get(model, 10)
        credits = per * duration * count
        unit = f"{duration}秒 x {count}本"
    usd = credits * USD_PER_CREDIT
    jpy = usd * JPY_PER_USD
    print("=== コスト概算 ===")
    print(f"model    : {model}")
    print(f"数量     : {unit}")
    print(f"credits  : {credits}")
    print(f"概算     : ${usd:.2f}  /  約{jpy:.0f}円")
    print("(turbo で構図確定 -> gen4.5 本番 が最安。いきなり本番は浪費)")
    return credits


def report(budget):
    if not LEDGER.exists():
        print("台帳なし:", LEDGER)
        return
    month = dt.datetime.now().strftime("%Y-%m")
    by_model = defaultdict(lambda: [0, 0.0])   # credits, jpy
    month_jpy = 0.0
    total_jpy = 0.0
    with LEDGER.open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            c = int(row["credits"])
            j = float(row["jpy"])
            by_model[row["model"]][0] += c
            by_model[row["model"]][1] += j
            total_jpy += j
            if row["ts"].startswith(month):
                month_jpy += j
    print("=== 台帳集計 ===")
    for m, (c, j) in sorted(by_model.items(), key=lambda x: -x[1][1]):
        print(f"  {m:12s}  {c:8d} cr   約{j:,.0f}円")
    print(f"  {'-'*32}")
    print(f"  累計                     約{total_jpy:,.0f}円")
    print(f"  今月({month})            約{month_jpy:,.0f}円")
    if budget:
        pct = month_jpy / budget * 100
        bar = "#" * int(pct // 5)
        print(f"\n  月次上限 {budget:,}円 に対し {pct:.0f}%  [{bar}]")
        if pct >= 80:
            print("  [!] 上限80%超。ペース注意。")
        if pct >= 100:
            print("  [!!] 上限超過。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="gen4.5")
    ap.add_argument("--duration", type=int, default=5)
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--images", type=int, default=0)
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--budget", type=int, default=0)
    a = ap.parse_args()
    if a.report:
        report(a.budget)
    else:
        estimate(a.model, a.duration, a.count, a.images)


if __name__ == "__main__":
    main()
