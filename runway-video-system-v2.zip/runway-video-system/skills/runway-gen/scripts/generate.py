#!/usr/bin/env python3
"""
Runway 生成の統一ラッパ。t2i / i2v / v2v(Aleph) を1つのCLIで。
- 非同期タスク待機、429 指数バックオフ、成果物DL保存、コスト台帳追記。
- SDK: pip install runwayml requests
- env: RUNWAYML_API_SECRET

モデル文字列・引数は Runway 側更新で変わりうる。失敗時は
https://docs.dev.runwayml.com/guides/models で確認すること。
"""
import argparse
import base64
import csv
import datetime as dt
import os
import random
import sys
import time
from pathlib import Path

try:
    from runwayml import RunwayML
    from runwayml import TaskFailedError
except ImportError:
    print("[!] runwayml SDK 未導入 -> pip install runwayml", file=sys.stderr)
    sys.exit(1)

import requests

# --- コスト表（cost.py と同一定義。変更時は両方更新）---
# credit/秒 は概算。API の実レートは docs/pricing で確認。
CREDIT_PER_SEC = {
    "gen4_turbo": 5,
    "gen4.5": 12,
    "aleph": 15,
}
CREDIT_PER_IMAGE = {
    "gen4_image": 5,
    "gpt_image_2": 8,
}
USD_PER_CREDIT = 0.05          # docs 記載の概算
JPY_PER_USD = 155.0            # 為替は都度更新
LEDGER = Path(os.environ.get("RUNWAY_LEDGER",
              Path(__file__).resolve().parents[3] / "infra" / "cost_ledger.csv"))


def _client() -> RunwayML:
    if not os.environ.get("RUNWAYML_API_SECRET"):
        print("[!] env RUNWAYML_API_SECRET 未設定", file=sys.stderr)
        sys.exit(1)
    return RunwayML()


def _data_uri(path: str) -> str:
    """ローカル画像/動画を data URI 化。Runway は URL か data URI を受ける。"""
    p = Path(path)
    ext = p.suffix.lower().lstrip(".")
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
            "webp": "image/webp", "mp4": "video/mp4", "mov": "video/quicktime"}.get(ext, "application/octet-stream")
    b64 = base64.b64encode(p.read_bytes()).decode()
    return f"data:{mime};base64,{b64}"


def _with_retry(fn, max_tries=5):
    """429/一時失敗を指数バックオフ。"""
    for i in range(max_tries):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001
            msg = str(e).lower()
            transient = "429" in msg or "rate" in msg or "timeout" in msg or "503" in msg
            if not transient or i == max_tries - 1:
                raise
            wait = (2 ** i) + random.uniform(0, 1)
            print(f"[retry] {e} -> {wait:.1f}s 待機 ({i+1}/{max_tries})", file=sys.stderr)
            time.sleep(wait)


def _download(url: str, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    r = requests.get(url, timeout=120)
    r.raise_for_status()
    out_path.write_bytes(r.content)
    print(f"[saved] {out_path}  ({len(r.content)//1024} KB)")


def _ledger(model, kind, duration, count, seed, out_path, credits):
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    new = not LEDGER.exists()
    with LEDGER.open("a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["ts", "kind", "model", "duration_s", "count",
                        "seed", "credits", "usd", "jpy", "out"])
        usd = credits * USD_PER_CREDIT
        w.writerow([dt.datetime.now().isoformat(timespec="seconds"), kind, model,
                    duration, count, seed, credits, round(usd, 3),
                    round(usd * JPY_PER_USD, 1), str(out_path)])


def _est_credits(kind, model, duration, count):
    if kind == "t2i":
        return CREDIT_PER_IMAGE.get(model, 5) * count
    per = CREDIT_PER_SEC.get(model, 10)
    return per * int(duration) * count


def _out_name(project, shot, model, seed, ext):
    day = dt.datetime.now().strftime("%Y%m%d")
    return f"{day}_{shot}_{model}_{seed}.{ext}"


def run_t2i(c, a):
    seed = a.seed if a.seed is not None else random.randint(1, 2**31)
    task = _with_retry(lambda: c.text_to_image.create(
        model=a.model, prompt_text=a.prompt, ratio=a.ratio, seed=seed,
    ).wait_for_task_output())
    url = task.output[0]
    out = Path(a.out) / _out_name(a.project, a.shot, a.model, seed, "png")
    _download(url, out)
    _ledger(a.model, "t2i", 0, 1, seed, out, _est_credits("t2i", a.model, 0, 1))
    return out


def run_i2v(c, a):
    seed = a.seed if a.seed is not None else random.randint(1, 2**31)
    img = a.image if a.image.startswith("http") else _data_uri(a.image)
    task = _with_retry(lambda: c.image_to_video.create(
        model=a.model, prompt_image=img, prompt_text=a.prompt,
        ratio=a.ratio, duration=a.duration, seed=seed,
    ).wait_for_task_output())
    url = task.output[0]
    out = Path(a.out) / _out_name(a.project, a.shot, a.model, seed, "mp4")
    _download(url, out)
    _ledger(a.model, "i2v", a.duration, 1, seed, out,
            _est_credits("i2v", a.model, a.duration, 1))
    return out


def run_v2v(c, a):
    seed = a.seed if a.seed is not None else random.randint(1, 2**31)
    vid = a.video if a.video.startswith("http") else _data_uri(a.video)
    task = _with_retry(lambda: c.video_to_video.create(
        model="aleph", video_uri=vid, prompt_text=a.prompt, seed=seed,
    ).wait_for_task_output())
    url = task.output[0]
    out = Path(a.out) / _out_name(a.project, a.shot, "aleph", seed, "mp4")
    _download(url, out)
    _ledger("aleph", "v2v", a.duration or 0, 1, seed, out,
            _est_credits("i2v", "aleph", a.duration or 5, 1))
    return out


def main():
    ap = argparse.ArgumentParser(description="Runway 生成ラッパ")
    sub = ap.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--model", required=True)
    common.add_argument("--prompt", required=True)
    common.add_argument("--project", default="misc")
    common.add_argument("--shot", default="shot")
    common.add_argument("--out", default="./assets")
    common.add_argument("--seed", type=int, default=None)

    p1 = sub.add_parser("t2i", parents=[common])
    p1.add_argument("--ratio", default="1920:1080")

    p2 = sub.add_parser("i2v", parents=[common])
    p2.add_argument("--image", required=True)
    p2.add_argument("--ratio", default="1280:720")
    p2.add_argument("--duration", type=int, default=5)

    p3 = sub.add_parser("v2v", parents=[common])
    p3.add_argument("--video", required=True)
    p3.add_argument("--duration", type=int, default=5)

    a = ap.parse_args()
    c = _client()
    try:
        if a.cmd == "t2i":
            run_t2i(c, a)
        elif a.cmd == "i2v":
            run_i2v(c, a)
        elif a.cmd == "v2v":
            run_v2v(c, a)
    except TaskFailedError as e:
        print("[FAILED] タスク失敗（prompt/モデレーション要確認）", file=sys.stderr)
        print(getattr(e, "task_details", e), file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
