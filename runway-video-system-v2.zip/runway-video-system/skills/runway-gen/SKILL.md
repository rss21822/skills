---
name: runway-gen
description: >
  Runway API で動画・画像を生成する中核スキル。text-to-image / image-to-video /
  video-to-video(Aleph) の呼び出し、モデル選択、非同期タスクの待機、リトライ、
  同時実行キュー制御、生成前のコスト概算表示、成果物の命名保存規約を扱う。
  「Runwayで動画作って」「gen4.5で生成」「i2v」「Alephで編集」「動画AI生成」
  など Runway での生成が絡む場面で必ず使う。生成前に必ずコスト概算を出すこと。
---

# runway-gen

Runway API 生成の中核。全ての生成はこのスキル経由で行う。

## 前提

- 環境変数 `RUNWAYML_API_SECRET` に API キー。無ければ生成中止し設定を促す。
- 公式 SDK: `pip install runwayml`（Python）/ `npm i @runwayml/sdk`（Node）
- 課金は消費者プランと別。**生成前に必ずコスト概算を表示**（`scripts/cost.py`）。
- 非同期タスク型。`.create(...).wait_for_task_output()` で完了待機、`task.output[0]` が URL。

## モデル選択（2026基準・docs で最新確認）

- `gen4_turbo` = 試作・イテレーション。安価・高速。ボツ前提の探索用。
- `gen4.5` = 本番・納品用。最高品質。director 承認済ショットのみ。
- `video_to_video`(Aleph 2.0) = 既存映像の編集。天候追加/再ライティング/不要物除去。
  → gameplay 補正は `aleph-gameplay-enhance` skill 側。
- `text_to_image`(gen4_image / GPT Image 2) = 参照フレーム・キーフレーム先行生成。
- i2v は参照画像1枚必須。キャラ・場所の一貫性維持は参照画像がキモ（`storyboard-to-video` 参照）。

モデル文字列・引数は更新される。不明時は https://docs.dev.runwayml.com/guides/models で確認。

## 生成フロー（厳守）

1. **コスト概算**: `python scripts/cost.py --model <m> --duration <s> --count <n>`
   → credit 消費と概算円を表示。**ユーザー承認前に本番生成しない**（turbo試作は承認不要可）。
2. **生成実行**: `python scripts/generate.py`（引数は下記）。
3. **保存**: 成果物は規約パスへ。命名 = `assets/{project}/{YYYYMMDD}_{shot}_{model}_{seed}.mp4`
4. **台帳追記**: 消費 credit を `infra/cost_ledger.csv` に自動記録（generate.py が実行）。

## generate.py の使い方

```bash
# text-to-image（参照フレーム生成）
python scripts/generate.py t2i \
  --model gen4_image --prompt "..." --ratio 1920:1080 \
  --project CAD --shot ref_drone_front --out assets/CAD/

# image-to-video（本命）
python scripts/generate.py i2v \
  --model gen4.5 --image assets/CAD/ref_drone_front.png \
  --prompt "..." --ratio 1280:720 --duration 5 \
  --project CAD --shot s01 --out assets/CAD/

# video-to-video（Aleph 編集）
python scripts/generate.py v2v \
  --model aleph --video in.mp4 --prompt "add rain, golden hour" \
  --project CAD --shot s01_rain --out assets/CAD/
```

## リトライ・同時実行

- HTTP 429（レート制限）= 指数バックオフで自動リトライ（generate.py 内蔵、最大5回）。
- 同時実行は標準ティアで数本まで。`--concurrency` で上限指定（既定3）。バッチは内部キューで直列化。
- `TaskFailedError` = プロンプト/モデレーション起因。`task_details` を出力しユーザーに提示、prompt 見直し。

## コスト意識

- turbo で構図・動き確定 → gen4.5 で本番、が credit 最小。いきなり gen4.5 は浪費。
- 生成前概算を出さずに本番回すのは禁止。credit は現金。
- 月次上限は `infra/cost_ledger.csv` の集計でアラート（`python scripts/cost.py --report`）。

## 失敗時

- 429 連発 → ティア上限。usage 確認を促す。
- モデレーション弾かれ → prompt から該当語除去し再試行。原因語をユーザーに伝える。
- 出力が意図と違う → 再生成前に `video-qc` で NG 理由を特定し prompt 修正。盲目的再生成は credit 浪費。
