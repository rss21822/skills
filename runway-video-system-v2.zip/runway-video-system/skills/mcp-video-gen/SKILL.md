---
name: mcp-video-gen
description: >
  Runway MCP コネクタ経由で動画・画像を生成する規約。runway-gen(API版)の姉妹スキル。
  MCPツール呼び出しの手順、モデル選択、consumer credit 管理、成果物のDL保存、
  media_cost_ledger への記録、API版との使い分けを扱う。「Runway MCPで生成」「MCPで動画」
  「チャットから動画作って」やコネクタ接続環境での生成依頼で必ず使う。
  API(generate.py)とMCPは課金枠が別である点を常に意識する。
---

# mcp-video-gen

Runway MCP（`https://mcp.runwayml.com/mcp`、OAuth接続）経由の生成規約。

## 前提

- コネクタ接続済み（claude.ai/Desktop: 設定→コネクタ→カスタム追加 / Code: `claude mcp add --transport http runway https://mcp.runwayml.com/mcp`）。
- 課金 = **Runway consumer credits**（Webアプリと同レート）。API課金(`RUNWAYML_API_SECRET`)とは**別枠**。
- 生成物は Runway ライブラリに保存＋会話に返る。ローカル利用時はDLして命名規約で保存。

## API版との使い分け（判断表）

- **MCP を使う**: 単発試作 / アイデア検証 / 会話文脈をそのまま生成に引き継ぎたい / 記事用1カット / コネクタしか無い環境。
- **API(generate.py) を使う**: 量産バッチ / Agent Team 自動化 / seed・台帳の厳密管理 / CI組込み。
- 迷ったら: 3本以下=MCP、4本以上 or 再現性必須=API。

## モデル選択（API版と同思想）

- 試作: Seedance系/turbo系の安価モデル → 構図・動き確定。
- 本番: Gen-4.5。director承認後のみ。
- MCP は Gen-4.5 / Seedance 2.0 / Kling / GPT Image 2 等を1接続で選べる。プロンプト内 or 指示でモデル明示。

## 生成フロー（厳守）

1. **残credit意識**: 大量生成前はRunwayアカウントの残creditをユーザーに確認してもらう。
2. **概算宣言**: モデル×秒数×本数から概算を言語化しユーザー承認（本番モデルは必須）。
3. **生成**: MCPツール呼び出し。prompt は `runway-prompt-craft` 規約準拠（構造・negative同一）。
4. **DL保存**: `assets/{project}/{YYYYMMDD}_{shot}_{model}_mcp.mp4`（seed非公開のため suffix=mcp）。
5. **台帳**: `python infra/ledger.py add --billing runway_mcp --item "<shot> <model> <sec>s" --credits <n>`
6. **QC**: `video-qc` ゲート必須。MCP生成物も例外なし。

## 注意

- 非同期・遅延変動あり。短尺プレビュー→本番、変種は意図的バッチで費用制御。
- seed 指定・取得はAPI比で制約 → 再現性重視の本番はAPI推奨。
- prompt 資産化は同一運用: QC PASS → `runway-prompt-craft/references/templates.md` 追記。
