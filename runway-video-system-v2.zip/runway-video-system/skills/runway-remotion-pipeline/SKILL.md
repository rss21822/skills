---
name: runway-remotion-pipeline
description: >
  Runway 生成素材を Remotion で合成し、テロップ・HUD・BGM を載せて 9:16/16:9/1:1 で
  一括書き出すスキル。既存 Creator Analytics HUD テンプレの流用、TikTok/Shorts/
  UGCメディア埋込の各仕様プリセット、複数アスペクト比の同時出力を扱う。
  「テロップ入れて」「合成」「Remotionで」「縦横両方書き出し」「HUD載せて」
  「トレーラー仕上げ」と言われた時や、Runway 素材を最終動画にする段で必ず使う。
  AI生成させると崩れる文字情報は全てこの Remotion 合成側で載せる。
---

# runway-remotion-pipeline

Runway 素材 → Remotion 合成 → マルチアスペクト書き出し。**文字は全部ここで載せる**
（Runway に文字生成させると崩れる）。

## 前提

- Remotion プロジェクト（既存 UGC 制作パイプライン流用）。`npx remotion` で render。
- 素材 = runway-gen が出した mp4/png（`assets/{project}/`）。
- 既存資産: Creator Analytics HUD テンプレ（Remotion）を HUD 系に流用。

## 合成レイヤ（下→上）

1. Runway 動画（背景）
2. カラーグレード / トランジション（クロスフェード、cut）
3. HUD / オーバーレイ（Creator Analytics HUD テンプレ等）
4. テロップ（日本語字幕、キャプション）— safe area 内
5. ロゴ / ウォーターマーク / CTA
6. BGM / SE（別途）

## プラットフォーム別プリセット

- **TikTok/Shorts (720:1280, 縦)**: safe area = 上14%/下20% 除外（UI被り回避）。
  テロップは中央〜やや上。掴み 2秒以内にフック字幕。
- **YouTube横 (1920:1080)**: 下 1/3 にテロップ、右下ロゴ。
- **UGCメディア埋込 (1280:720 or 1080:1080)**: 記事内再生前提。字幕大きめ、無音でも成立させる。

## マルチアスペクト一括書き出し

同一コンポジションを props で ratio 切替 → 3比率同時 render。

```bash
# 例: 縦/横/正方 を連続 render
for r in 720x1280 1920x1080 1080x1080; do
  W=${r%x*}; H=${r#*x}
  npx remotion render src/index.ts Main out/${PROJECT}_${W}x${H}.mp4 \
    --props="{\"src\":\"assets/${PROJECT}/final.mp4\",\"w\":${W},\"h\":${H}}"
done
```

Remotion 側 `<Composition>` は `useVideoConfig()` で w/h を受け、safe area・テロップ位置を
比率で分岐（縦=中央上、横=下1/3）。

## テロップ規約

- 日本語: 1行 全角13-16字、最大2行。読める速度（1字/0.1s目安）。
- AI 生成動画内の「文字っぽいもの」は QC で崩れ検出 → ここで正規テロップに置換。
- フォント埋込。UGC Game メディアはブランドフォント統一。

## フロー

1. QC PASS 素材を集約 → タイムライン順に配置。
2. テロップ台本（日本語）を用意 → Remotion コンポに流し込み。
3. HUD/ロゴ/BGM 載せ。
4. 3比率一括 render → `out/`。
5. compositor agent が担当。書き出し後 archivist が記録。
