---
name: video-qc
description: >
  Runway 等で生成した動画の品質検査。ffmpeg でフレーム抽出し、morphing(溶け崩れ)、
  手指の破綻、文字崩れ、ループ継ぎ目、フリッカ、被写体一貫性欠如を検出。合否判定と
  NG時の prompt 修正指針を返す。生成動画を「チェック」「QC」「確認」「使える?」
  「変じゃない?」と問われた時や、再生成の前に必ず使う。盲目的な再生成は credit 浪費
  なので、NG原因を特定してから作り直すためのゲートとして機能する。
---

# video-qc

生成動画の合否ゲート。**再生成前に必ず通す**。原因不明のまま作り直すと credit を溶かす。

## なぜ必要か

AI 動画の失敗は再現性が低い。「なんか変」で盲目再生成 → また変、を繰り返すと
credit が消える。QC で「どこが・なぜ」を特定 → prompt/seed/参照画像を狙って直す。

## フロー

1. **フレーム抽出**: `python scripts/qc.py extract <video.mp4>`
   → 均等 N 枚 + 先頭/末尾（ループ継ぎ目用）を `qc_frames/` に出力。
2. **目視検査**: 抽出フレームを `view` で読み、下記チェックリストで判定。
3. **判定出力**: 合否 + NG項目 + 原因推定 + prompt 修正案。
4. NG なら `prompt-writer`/ユーザーへ差し戻し。OK なら compositor へ。

## チェックリスト（各項目 pass/fail + 根拠フレーム番号）

- **morphing**: 被写体が別物に溶け変わる。特に機体・艦船の輪郭。
- **手指・肢体**: 指本数、関節破綻、余剰四肢。人物/オペレータ映る時。
- **文字崩れ**: 機体マーキング、UI風テキスト、ロゴが読めない崩れ字。
- **ループ継ぎ目**: 先頭↔末尾フレーム差。SNS ループ用途では致命。
- **フリッカ**: 隣接フレームの明滅・チラつき。テクスチャ面で顕著。
- **一貫性**: 参照画像の色・形状を維持しているか（gen4 参照使用時）。
- **物理破綻**: 水面/煙/軌跡の不自然な動き。CAD/CAA は流体多く要注意。
- **カメラ**: 指定カメラワーク（arc/zoom/truck）と一致するか。

## 判定基準

- 致命(morphing/文字崩れ/一貫性欠如) が1つでも → **FAIL**、再生成。
- 軽微(端の微フリッカ等) のみ → **PASS with note**、Aleph 補正 or トリムで回避可。
- 全項目 clear → **PASS**。

## NG別 prompt 修正指針

- morphing → negative に `morphing, distorted, warping`。duration 短縮。参照画像追加。
- 手指破綻 → 手をフレーム外に。`hands hidden` or ロング寄りの構図指定。
- 文字崩れ → 文字は AI 生成させず Remotion 側でテロップ合成（`runway-remotion-pipeline`）。
- ループ継ぎ目 → 尺を割り切れる秒数に。ping-pong 合成を compositor 側で。
- フリッカ → seed 変更、turbo→gen4.5 昇格、Aleph で安定化。
- 一貫性欠如 → 参照画像の質を上げる（正面/側面/俯瞰の3枚。`storyboard-to-video`）。

## 出力フォーマット（固定）

```
## QC結果: <video名>
判定: PASS / PASS w/note / FAIL
--
[項目] pass/fail  根拠: frame_NN  所見: ...
...
--
原因推定: ...
修正案: ...（FAIL/note時のみ）
再生成コスト概算: cost.py で <model> <duration> の見積を併記
```
