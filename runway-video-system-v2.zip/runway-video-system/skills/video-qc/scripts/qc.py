#!/usr/bin/env python3
"""
QC用フレーム抽出。ffmpeg 必須。
  python qc.py extract video.mp4 --n 8 --out qc_frames/
均等 n 枚 + 先頭/末尾(ループ継ぎ目検査用)を出力。
末尾に diff サマリ(先頭↔末尾の平均画素差)を表示 -> ループ適性の一次判定。
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def _need(cmd):
    if shutil.which(cmd) is None:
        print(f"[!] {cmd} 未導入。ffmpeg を入れること。", file=sys.stderr)
        sys.exit(1)


def probe_duration(video):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", video],
        capture_output=True, text=True, check=True)
    return float(json.loads(out.stdout)["format"]["duration"])


def extract(video, n, out):
    _need("ffmpeg"); _need("ffprobe")
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    dur = probe_duration(video)
    # 均等 n 枚 + 先頭(0) + 末尾(dur-0.05)
    times = [round(dur * i / (n - 1), 3) for i in range(n)] if n > 1 else [0.0]
    times = sorted(set([0.0] + times + [max(0.0, dur - 0.05)]))
    frames = []
    for i, t in enumerate(times):
        fp = out / f"frame_{i:02d}_t{t:0.2f}.png"
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(t), "-i", video, "-frames:v", "1",
             "-q:v", "2", str(fp)],
            capture_output=True, check=True)
        frames.append(str(fp))
    print(f"[extract] {len(frames)} frames -> {out}  (duration {dur:.2f}s)")
    for f in frames:
        print("  ", f)
    print("\n次: 抽出フレームを view で読み、SKILL.md チェックリストで判定。")
    print("特に frame_00 (先頭) と最終フレーム(末尾) を並べてループ継ぎ目確認。")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("extract")
    e.add_argument("video")
    e.add_argument("--n", type=int, default=8)
    e.add_argument("--out", default="qc_frames")
    a = ap.parse_args()
    if a.cmd == "extract":
        extract(a.video, a.n, a.out)


if __name__ == "__main__":
    main()
