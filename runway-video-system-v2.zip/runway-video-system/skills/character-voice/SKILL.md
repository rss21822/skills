---
name: character-voice
description: >
  ElevenLabs MCP でキャラクターボイス・ナレーション・SE/BGM を制作するスキル。
  オリジナルAI音声の設計(text_to_voice)→試聴選択→ライブラリ登録、voice_library.json
  台帳管理、日本語TTS規約、delivery演出、実尺計測とshotlistへの書き戻し、credit防衛を
  扱う。「キャラ声作って」「ナレーション生成」「ボイス」「セリフ音声化」「SE作って」
  「BGM」など音声制作全般で必ず使う。実在人物の声クローンは扱わない。
---

# character-voice

ElevenLabs MCP 音声制作の中核。**オリジナル声のみ**（text_to_voice 由来）。実在人物クローン禁止=権利安全。

## 前提

- ElevenLabs MCP 導入済み（ローカルstdio: `uvx elevenlabs-mcp`＋`ELEVENLABS_API_KEY`、
  Claude Desktop/Code 設定に記述。Windows は Developer Mode 必須）。
- 出力先は `ELEVENLABS_MCP_BASE_PATH` で制御（既定 ~/Desktop → プロジェクト配下推奨）。
- credit課金（無料枠1万/月）。**voice design は重い処理**＝時間もcreditも食う。

## オリジナル声設計フロー

1. `check_subscription` で残credit確認（必須先打ち）。
2. キャラ設計文を書く（`references/voice_direction.md` の型を使用。日本語話者・年齢感・
   質感・役割を含む英語説明文）。
3. `text_to_voice` で候補生成（3バリエーション出させる）→ ユーザー試聴。
4. 選ばれた候補を `create_voice_from_preview` でライブラリ登録 → voice_id 取得。
5. `infra/voice_library.json` に記録（character / voice_id / 設計文 / サンプルパス / 用途 / 日付）。

## TTS 実生成フロー

1. 台本（scriptwriter 出力）から話者ごとにテキスト分割。
2. voice_library.json から voice_id 引き当て。未登録キャラは設計フローへ。
3. `text_to_speech` 実行。日本語は多言語対応モデルを使用（`list_models` で現行確認）。
   settings 目安: ナレーション=stability高め / キャラ芝居=stability低め+style高め。
4. 出力を `assets/{project}/vo/{shot}_{speaker}.mp3` に保存。
5. **実尺計測**: `ffprobe` で秒数取得 → shotlist の `audio_sec` に書き戻し。
   （動画尺は音声実尺から決まる。voice-first原則 → `av-sync-produce`）
6. 台帳: `python infra/ledger.py add --billing elevenlabs --item "<shot> tts <文字数>字" --credits <概算>`

## SE / BGM

- SE: `text_to_sound_effects`（例: "drone rotor spin-up, mechanical whir"）。
- BGM: `compose_music`。尺指定して生成、mux 時にダッキング前提。
- どちらも同じ保存規約 `assets/{project}/se/`, `assets/{project}/bgm/`。

## 音声QC観点（qc-reviewer と共有）

読み間違い / 不自然イントネーション / 数字・英字の読み / ノイズ・こもり / 尺が想定と乖離 /
話者間の音量差。NG は delivery 文言修正 or settings 調整で再生成（丸ごと再設計しない）。

## credit 防衛

- `check_subscription` を制作セッション冒頭に必ず1回。
- 編集のたびに全文再TTSしない。**変更セリフ行のみ再生成**。
- voice design は候補3つまで/キャラ。気に入らなければ設計文を直して再挑戦（乱発しない）。
