# 声設計・演出の型集

text_to_voice の設計文（英語推奨）と、TTS delivery の型。成功した設計文は
voice_library.json と併せてここに追記して資産化。

## 設計文テンプレ

```
[年齢感] [性別/中性] Japanese speaker, [声質: warm/clear/husky/metallic...],
[話速・トーン: calm and measured / energetic...], [役割: narrator for gaming videos /
AI flight controller / ship captain...], [質感補足: slight synthetic edge 等]
```

## プロジェクト別の初期キャラ案

### UGC Game ナレーター（メディア動画の顔）
```
A clear, friendly Japanese narrator in their late 20s, neutral gender leaning female,
warm but crisp articulation, medium-fast pace suited for tech explainer videos,
confident and approachable, no vocal fry.
```
用途: 解説動画・トレーラーVO標準。stability 高め。

### CAD 管制AI（ドローン管制ボイス）
```
A calm synthetic female Japanese voice, AI flight controller persona, precise and
slightly metallic, even pacing with clinical composure, subtle digital texture,
reassuring under pressure.
```
用途: CAD トレーラー/ゲーム内風演出。stability 高・style 低。

### CAA 艦艇キャラ（少し芝居がかった艦長格）
```
A commanding Japanese female voice in her 30s, naval officer persona, firm and
resonant with controlled intensity, theatrical but disciplined delivery,
slight warmth beneath authority.
```
用途: CAA 世界観ボイス。stability 中・style 高め。

### Paint&Snipe 実況調
```
An energetic Japanese male caster voice, esports commentary style, quick tempo,
punchy emphasis, bright tone, excitable but articulate.
```
用途: 紹介動画のテンション枠。stability 低め・style 高め。

## delivery（読み）演出の型

- 間: 文中の意図的ポーズは「、」「…」や文分割で作る（長文一気読みさせない）。
- 強調: 強調語の直前で文を切る。カギ括弧はやや演技がかる傾向。
- 数字・英字: 読み間違い頻発帯。カタカナ書き下し（例: ジェンヨンテンファイブ）で固定。
- テンション制御: settings より台本表記の影響が大きい。「!」多用=上振れ。
- 尺調整: 削る優先。読速を無理に変えると不自然化。1行=全角20-35字で約3-6秒目安。

## 禁止

- 実在人物の声真似設計（「〜さん風」を設計文に書かない）。
- voice_clone の使用（本システムでは text_to_voice 由来のみ）。
