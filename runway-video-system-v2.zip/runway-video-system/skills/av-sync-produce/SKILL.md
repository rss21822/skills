---
name: av-sync-produce
description: >
  企画→脚本→ボイス→映像→QC→合成→書き出しを一気通貫で回すオーケストレーション
  スキル。voice-first/video-first の判定、音声実尺からの動画尺確定、ffmpegによる
  VO/BGM mux、リップシンク回避の構図設計を扱う。「一気通貫で作って」「企画から
  動画まで」「音声付き動画」「セリフ入りトレーラー」「フル制作」と言われた時、
  および音声と映像を組み合わせる制作全般で必ず使う。全体の指揮系統を定義する
  マスタースキル。
---

# av-sync-produce

一気通貫制作の指揮系統。個別作業は各専門スキルに委譲し、本スキルは**順序・尺整合・合成**を握る。

## 全体フロー

```
企画 → 脚本(scriptwriter/セリフ・話者) → 声設計・TTS(character-voice)→実尺確定
 → shotlist(storyboard-to-video/尺=音声実尺基準) → prompt(runway-prompt-craft)
 → 映像生成(mcp-video-gen or runway-gen) → QC(video-qc/映像+音声)
 → mux+テロップ(本スキル+runway-remotion-pipeline) → 3比率書出 → 記録(archivist)
```

## voice-first / video-first 判定

- **voice-first（原則）**: セリフ・ナレーションがある制作。音声は実尺固定、動画は5/10s刻み
  → TTS先行 → 実尺から動画尺を決める。
- **video-first**: ナレ無し環境映像 / gameplay補正主体 / ループ素材。映像先行、SE/BGMを後嵌め。
- 混在時: セリフ乗るショットだけ voice-first、他は video-first。

## 尺確定式（voice-first）

```
video_sec(shot) = ceil( (audio_sec + margin) / 5 ) * 5    # margin=0.5〜1.0s
```
- `scripts/avmux.py fit <audio.mp3>` が計算。10s超は分割検討（1ショット1アクション原則）。
- 逆流禁止: 音声が長すぎるなら**台本を削る**（読速いじり・映像引き伸ばしは不自然化）。

## mux 規約

- ツール: `scripts/avmux.py mux --video v.mp4 --vo vo.mp3 [--bgm bgm.mp3] --out final.mp4`
  - VOそのまま、BGMは自動 -12dB相当に減衰して混合（ダッキング簡易版）。
  - 映像は再エンコード無し(copy)、音声はAAC。
- 複数ショット連結後に全体VOを乗せる場合: 先に映像連結(`concat`) → mux。
- テロップ・HUD は mux 後の Remotion 工程（`runway-remotion-pipeline`）。字幕は音声と一致必須。

## リップシンク回避（設計段階で潰す）

AI動画の口パク一致は高難度。shotlist 設計時に以下の構図でセリフを乗せる:
- ナレーション主体（画面外の声）
- キャラは 引き / 後ろ姿 / シルエット / コクピット・ヘルメット越し / マスク・バイザー
- 口元が映る場合はセリフでなく SE/BGM 区間に
- どうしても正面口パクが要る時のみ Act-Two 検討（別案件扱い、後回し）

## QC 二重ゲート

1. 映像QC: `video-qc`（従来通り）。
2. 音声QC: character-voice の観点（読み・ノイズ・尺）。
3. mux後QC: 音ズレ / 音量バランス / 字幕と音声の一致。ズレは concat 順序と尺丸めをまず疑う。

## 最小構成の1本（推奨初回）

CAD 15秒縦トレーラー: ナレーター1話者 × 3ショット(5s×3) × BGM1曲。
scriptwriter→voice-director→media-generator→qc-reviewer→compositor の順で貫通確認。
