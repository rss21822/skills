#!/usr/bin/env python3
"""
音声実尺→動画尺確定 & VO/BGM mux。ffmpeg/ffprobe 必須。
  python avmux.py probe vo.mp3                 # 実尺表示
  python avmux.py fit vo.mp3 --margin 0.8      # 推奨動画尺(5s刻み)
  python avmux.py mux --video v.mp4 --vo vo.mp3 --out final.mp4
  python avmux.py mux --video v.mp4 --vo vo.mp3 --bgm bgm.mp3 --out final.mp4
  python avmux.py concat a.mp4 b.mp4 c.mp4 --out joined.mp4
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def _need(cmd):
    if shutil.which(cmd) is None:
        print(f"[!] {cmd} 未導入。ffmpeg を入れること。", file=sys.stderr)
        sys.exit(1)


def probe(path) -> float:
    _need("ffprobe")
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", str(path)],
        capture_output=True, text=True, check=True)
    return float(json.loads(out.stdout)["format"]["duration"])


def fit(audio, margin):
    sec = probe(audio)
    need = sec + margin
    video_sec = max(5, math.ceil(need / 5) * 5)
    print(f"audio実尺 : {sec:.2f}s")
    print(f"margin    : {margin:.2f}s")
    print(f"推奨動画尺: {video_sec}s (5s刻み切り上げ)")
    if video_sec > 10:
        print("[!] 10s超。ショット分割を検討（1ショット1アクション原則）。")
    return video_sec


def mux(video, vo, bgm, out):
    _need("ffmpeg")
    v, a = probe(video), probe(vo)
    if a > v + 0.05:
        print(f"[!] VO({a:.2f}s) が映像({v:.2f}s) より長い。台本を削るか映像尺を再確定。",
              file=sys.stderr)
        sys.exit(2)
    # 映像長を正とし、音声は apad で映像末尾まで無音パディング（voice-first: 映像を切らない）
    if bgm:
        fc = ("[2:a]volume=0.25[b];"
              "[1:a][b]amix=inputs=2:duration=longest:dropout_transition=0,apad[a]")
        cmd = ["ffmpeg", "-y", "-i", video, "-i", vo, "-i", bgm,
               "-filter_complex", fc, "-map", "0:v", "-map", "[a]",
               "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", f"{v:.3f}", out]
    else:
        cmd = ["ffmpeg", "-y", "-i", video, "-i", vo,
               "-filter_complex", "[1:a]apad[a]",
               "-map", "0:v", "-map", "[a]",
               "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", f"{v:.3f}", out]
    subprocess.run(cmd, capture_output=True, check=True)
    print(f"[mux] {out}  (video {v:.2f}s / vo {a:.2f}s / bgm {'あり' if bgm else 'なし'})")
    print("次: mux後QC = 音ズレ・音量バランス・字幕一致 を確認。")


def concat(files, out):
    _need("ffmpeg")
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        for p in files:
            f.write(f"file '{Path(p).resolve()}'\n")
        lst = f.name
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", lst, "-c", "copy", out],
                   capture_output=True, check=True)
    total = probe(out)
    print(f"[concat] {len(files)}本 -> {out} ({total:.2f}s)")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("probe"); p.add_argument("audio")
    p = sub.add_parser("fit"); p.add_argument("audio")
    p.add_argument("--margin", type=float, default=0.8)
    p = sub.add_parser("mux")
    p.add_argument("--video", required=True); p.add_argument("--vo", required=True)
    p.add_argument("--bgm", default=None); p.add_argument("--out", required=True)
    p = sub.add_parser("concat"); p.add_argument("files", nargs="+")
    p.add_argument("--out", required=True)

    a = ap.parse_args()
    if a.cmd == "probe":
        print(f"{probe(a.audio):.2f}s")
    elif a.cmd == "fit":
        fit(a.audio, a.margin)
    elif a.cmd == "mux":
        mux(a.video, a.vo, a.bgm, a.out)
    elif a.cmd == "concat":
        concat(a.files, a.out)


if __name__ == "__main__":
    main()
