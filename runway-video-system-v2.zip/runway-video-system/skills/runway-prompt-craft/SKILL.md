---
name: runway-prompt-craft
description: >
  日本語の意図を Runway 向け英語プロンプトに変換するスキル。ショットタイプ先頭 →
  被写体 → 動作 → カメラワーク → ライティング → negative の順で構築する規則、
  ゲームジャンル別テンプレ(ドローン空戦/艦船/スナイパー視点)、成功プロンプトの
  蓄積運用を扱う。「プロンプト作って」「英語にして」「Runway用に」「どう書けば」
  と問われた時や、動画生成の前段で必ず使う。良いプロンプトは references/templates.md
  を参照し、成功例は同ファイルに追記して資産化する。
---

# runway-prompt-craft

日本語意図 → Runway 英語 prompt 変換。Runway は 2026 でカメラ用語・ライティング物理を
よく解釈する。構造化 prompt が品質を決める。

## 構築順（固定テンプレ）

```
[SHOT TYPE], [SUBJECT], [ACTION], [CAMERA], [LIGHTING], [STYLE]. --no [NEGATIVE]
```

1. **SHOT TYPE 先頭**: `Close up` / `Wide shot` / `Aerial view` / `FPV` / `Tracking shot`
   → 構図が確定し破綻が減る。必ず先頭。
2. **SUBJECT**: 被写体を具体的に。参照画像使用時は画像に寄せた記述。
3. **ACTION**: 動き。1ショット1アクション。詰め込むと morphing 誘発。
4. **CAMERA**: `slow arc around subject` / `dramatic zoom-in` / `truck left` / `orbit`。
5. **LIGHTING**: `golden hour` / `soft studio light` / `hard noir shadows` / `overcast`。
   ライティングが realism を左右。必ず指定。
6. **STYLE**: `cinematic, 4k, hyper-realistic` 等。ゲーム調なら別途。
7. **NEGATIVE**: `blurry, distorted, morphing, text, watermark, extra limbs`。

## 原則

- 1ショット1アクション。複数動作は複数ショットに割る。
- 文字は prompt に入れない → 崩れる。テロップは Remotion 側合成。
- 参照画像あるなら記述を画像に合わせる（矛盾させない）。一貫性は参照画像が主、textが従。
- turbo で構図探索 → 決まった prompt を gen4.5 に横流し。

## ゲームジャンル別テンプレ

詳細・実例は `references/templates.md`。要旨:

- **ドローン空戦(CAD)**: FPV/aerial 主体。`FPV drone racing through ...`、
  高速パン、モーションブラー許容、機体は参照画像で固定。
- **艦船(CAA)**: wide/aerial。航跡(wake)・水面が肝 → 物理破綻に注意、duration短め。
  `naval vessel cutting through water, wake trail, ...`。
- **スナイパー/FFA(Paint&Snipe)**: スコープ視点・遮蔽。`through sniper scope, ...`、
  被写界深度、緊張感のライティング。

## 資産化ループ

- 生成 → QC PASS した prompt は `references/templates.md` に frontmatter 付きで追記
  （model / ratio / seed / 用途 / 元動画パス）。
- 蓄積 prompt は The UGC Game メディアの記事ネタに転用可（「Runwayプロンプト集」系は
  日本語検索需要あり）。archivist agent が DB と templates.md を同期。

## 出力フォーマット

```
## Prompt: <用途>
EN: <SHOT>, <SUBJECT>, <ACTION>, <CAMERA>, <LIGHTING>, <STYLE>. --no <NEG>
JP意図: <元の日本語>
推奨: model=<> ratio=<> duration=<>
```
