# Runway プロンプトテンプレ集

構造: `[SHOT], [SUBJECT], [ACTION], [CAMERA], [LIGHTING], [STYLE]. --no [NEG]`
成功プロンプト(QC PASS)は末尾「蓄積」に frontmatter 付きで追記していく。

---

## ドローン空戦（CAD: Custom Armament Drones）

FPV/aerial 主体。高速・モーションブラー許容。機体は参照画像で固定。

- `FPV shot, an armed quadcopter drone, banking hard through a canyon at high speed, camera locked to the drone chassis, harsh midday sun with sharp shadows, cinematic, motion blur. --no morphing, distorted, text, extra propellers`
- `Aerial wide shot, a swarm of combat drones over a coastal military base, formation flying then splitting, slow orbit descending, golden hour backlight, hyper-realistic, 4k. --no warping, flicker, watermark`
- `Tracking shot, single drone releasing a payload, sharp pitch-down maneuver, camera trucks alongside, overcast diffuse light, gritty realism. --no blurry, morphing, extra limbs`

注意: プロペラは高速回転で崩れやすい → duration 短め(5s)、negative に `extra propellers`。

---

## 艦船（CAA: Custom Armament Avatar）

wide/aerial。航跡・水面が肝。物理破綻注意、duration 短め。

- `Wide shot, a stylized naval destroyer cutting through open ocean, bow wave and wake trail forming, slow arc from stern to bow, overcast sky soft light, cinematic naval, 4k. --no warping water, morphing, text`
- `Aerial view, fleet of warships in formation, gentle forward cruise, high orbit descending slowly, golden hour on water, hyper-realistic. --no flicker, distorted hull, watermark`
- `Low angle shot, warship main battery firing, muzzle flash and smoke, static camera slight shake, dramatic dusk lighting, film grain. --no morphing, extra turrets, blurry`

注意: 水面・航跡は AI が崩しやすい → duration 5s 上限推奨、`warping water` を negative。

---

## スナイパー / FFA（Paint & Snipe!）

スコープ視点・遮蔽・緊張感。被写界深度。

- `Through a sniper scope, crosshair on a distant moving target, subtle breathing sway, shallow depth of field, tense overcast light, cinematic thriller. --no morphing, distorted crosshair, text`
- `Over-the-shoulder shot, a camouflaged sniper prone in foliage, slow reveal, camera creeps forward, dappled forest light, gritty realism, 4k. --no extra limbs, warping, watermark`
- `Wide establishing shot, an urban rooftop battlefield at dawn, wind moving debris, static wide, cold blue morning light, cinematic. --no flicker, morphing, blurry`

注意: crosshair/UI 文字は AI 生成させない → Remotion 側で合成。

---

## 汎用（トレーラー冒頭 / ロゴ演出 / 引き）

- `Cinematic establishing shot, [場所], atmospheric, slow push-in, [時間帯] lighting, epic scale, 4k. --no text, watermark, morphing`
- `Macro close up, [オブジェクト] detail, subtle rotation, soft studio light, product-grade, hyper-realistic. --no distorted, blurry`

---

## 蓄積（QC PASS 済のみ追記）

<!-- 追記フォーマット:
### <用途短い名>
- prompt(EN): ...
- model: gen4.5 / ratio: 1280:720 / duration: 5 / seed: 12345
- src: assets/CAD/20260706_s01_gen4.5_12345.mp4
- 所見: 一発PASS / negに morphing 必須 等
-->

(まだ空。生成回して PASS したものから埋める)
