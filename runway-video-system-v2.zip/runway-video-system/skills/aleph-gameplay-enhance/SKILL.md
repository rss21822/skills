---
name: aleph-gameplay-enhance
description: >
  Roblox/UEFN の実プレイキャプチャを Runway Aleph 2.0 (video-to-video) で補正する
  スキル。text prompt で天候追加・再ライティング・不要UI除去・シネマ調グレーディングを
  かけ、実プレイ+AI補正のハイブリッドなトレーラー映像を作る。「実プレイを盛りたい」
  「Alephで加工」「ゲーム映像をシネマ調に」「UI消して」「雨降らせて」
  「トレーラー用に補正」と言われた時に必ず使う。ゼロから生成せず実キャプチャを土台に
  するので一貫性が高く、ゲームトレーラーに最適。
---

# aleph-gameplay-enhance

実プレイキャプチャ土台 + Aleph 補正。ゼロ生成より一貫性が高く、実際のゲーム画面なので
「本物」感が出る。トレーラーの主力手法。

## なぜハイブリッドか

- フル AI 生成 = 一貫性リスク・実ゲームと乖離。
- 実キャプチャのみ = 画作りが地味、天候/ライティング固定。
- Aleph = 実映像に prompt で天候・光・グレードを足す → 実物ベースで映える。

## 入力

Roblox Studio / UEFN のキャプチャ動画（OBS 等）。解像度・尺は Aleph 制約内に。
不要な開発UI・デバッグ表示が映っていても Aleph で消せる。

## Aleph でできる代表編集（text prompt）

- 天候追加: `add rain` / `add fog` / `add snow`
- 再ライティング: `change lighting to golden hour` / `dusk` / `night neon`
- 不要物除去: `remove the debug UI` / `remove HUD overlays`
- グレーディング: `cinematic color grade, teal and orange` / `film noir`
- 空・背景差替: `replace sky with dramatic storm clouds`

複数指示は1回に詰め込みすぎない。効き方を見て段階適用。

## フロー

1. キャプチャ取得（クリーンな画作り優先、後で補正する前提で撮る）。
2. コスト概算: `python ../runway-gen/scripts/cost.py --model aleph --duration <s>`。
3. Aleph 実行: `python ../runway-gen/scripts/generate.py v2v --model aleph
   --video capture.mp4 --prompt "add rain, cinematic teal-orange grade, remove debug UI"
   --project CAD --shot trailer_s03 --out assets/CAD/`
4. QC: `video-qc` で morphing・破綻確認（Aleph でも溶けは起きうる）。
5. PASS → Remotion 合成へ（テロップ・HUD は Remotion 側）。

## 注意

- Aleph は「編集」であって作り直しではない。元映像の構図・動きは保持される。
- 効きすぎ/破綻したら prompt を弱める（`subtle rain` 等）or 段階適用。
- 元キャプチャは高解像・安定フレームレートで。土台が汚いと補正も限界。
- ゲーム内の重要テキスト（スコア等）は消えると困る → prompt で `keep the score UI` 指定 or
  Remotion で後載せ前提に撮る。

## 用途例

- CAD/CAA トレーラー: 実戦闘プレイ + 天候ドラマ + シネマグレード。
- Paint&Snipe 紹介: 実カモフラ挙動 + 森の光補正で映え。
- UGC Game メディア: 「実装解説」動画の締めに映えカットを差す。
